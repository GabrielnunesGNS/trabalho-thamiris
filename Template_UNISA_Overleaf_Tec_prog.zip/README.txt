Projeto Overleaf UNISA
1. Faça upload deste ZIP em Overleaf > New Project > Upload Project.
2. Compile main.tex com pdfLaTeX.
3. O logotipo textual UNISA é provisório, NÃO é o símbolo oficial.
4. Para usar o símbolo oficial, obtenha o arquivo autorizado da instituição e salve como figuras/logo-unisa.png.
5. Duplique o bloco \exercicio{1.1} para cada questão.
